#!/bin/bash
myip=$(hostname -I)
echo $myip
